const express = require('express');  
const multer = require('multer');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // For password hashing
const jwt = require('jsonwebtoken'); // For creating JSON Web Tokens
require('dotenv').config(); // Load environment variables from .env file

// Initialize Express app
const app = express();

// Set up file storage for multer (for image uploads)
const storage = multer.diskStorage({
    destination: './uploads/', // Ensure the uploads directory exists
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

// Middleware to parse incoming JSON (for form submissions)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB schema for the reports
const ReportSchema = new mongoose.Schema({
    conditionType: String,
    location: String,
    description: String,
    photoUrl: String,
    createdAt: { type: Date, default: Date.now }, // Automatically add a timestamp
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Reference to the user who created the report
    userEmail: String // Store the user's email for easier display
});

const Report = mongoose.model('Report', ReportSchema);

// MongoDB schema for the users
const UserSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const User = mongoose.model('User', UserSchema);

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/roadcondition', { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Middleware for checking authentication
const authenticate = (req, res, next) => {
    const authHeader = req.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ success: false, message: 'Unauthorized: No token provided' });
    }

    const token = authHeader.split(' ')[1];

    jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key', (err, decoded) => {
        if (err) {
            return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
        }

        req.userId = decoded.userId; // Attach userId to request object
        next();
    });
};

// Handle POST requests to login a user
app.post('/api/users/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate the incoming data
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required.' });
        }

        // Check if the user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ success: false, message: 'Invalid email or password.' });
        }

        // Check the password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ success: false, message: 'Invalid email or password.' });
        }

        // Create a JWT token
        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'your_jwt_secret_key', { expiresIn: '1h' });

        res.json({ success: true, token, message: 'Login successful.' });
    } catch (error) {
        console.error('Error logging in user:', error);
        res.status(500).json({ success: false, message: 'Server error, please try again later.' });
    }
});

// Handle POST requests to submit a report (user must be logged in)
app.post('/api/reports', authenticate, upload.single('photo'), async (req, res) => {
    try {
        const { conditionType, location, description } = req.body;

        // Validate the incoming data
        if (!conditionType || !location || !description) {
            return res.status(400).json({ success: false, message: 'All fields are required.' });
        }

        const user = await User.findById(req.userId);
        if (!user) return res.status(401).json({ success: false, message: 'Invalid user.' });

        const reportData = {
            conditionType,
            location,
            description,
            userId: user._id,
            userEmail: user.email
        };

        // If a photo is uploaded, include it in the report
        if (req.file) {
            reportData.photoUrl = '/uploads/' + req.file.filename;
        }

        // Save the new report in the database
        const newReport = new Report(reportData);
        await newReport.save();

        res.json({ success: true, message: 'Report submitted successfully!' });
    } catch (error) {
        console.error('Error submitting report:', error);
        res.status(500).json({ success: false, message: 'Server error, please try again later.' });
    }
});

// Handle GET requests to fetch all reports (accessible to all users)
app.get('/api/reports', async (req, res) => {
    try {
        const reports = await Report.find().sort({ createdAt: -1 }); // Fetch reports sorted by creation date
        res.json({ success: true, reports });
    } catch (error) {
        console.error('Error fetching reports:', error.message || error);
        res.status(500).json({ success: false, message: 'Server error, please try again later.' });
    }
});

// Handle POST requests to register a new user
app.post('/api/users/register', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate the incoming data
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required.' });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ success: false, message: 'User already exists.' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user
        const newUser = new User({ email, password: hashedPassword });
        await newUser.save();

        res.json({ success: true, message: 'User registered successfully.' });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ success: false, message: 'Server error, please try again later.' });
    }
});

// Serve uploaded files (e.g., images)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve the report submission page
app.get('/submit-report', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'submit-report.html'));
});

// Serve the all reports page
app.get('/all-reports', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'view-reports.html'));
});

// Start the server
app.listen(5000, () => {
    console.log('Server running on port 5000');
});