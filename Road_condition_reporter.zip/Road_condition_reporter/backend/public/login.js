document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/api/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (data.success) {
            localStorage.setItem('token', data.token); // Store token in localStorage
            window.location.href = 'dashboard.html';  // Redirect to dashboard after successful login
        } else {
            document.getElementById('error-message').textContent = data.message; // Display server message
            document.getElementById('error-message').style.display = 'block';
        }
    } catch (error) {
        console.error('Error logging in:', error);
        document.getElementById('error-message').textContent = 'An unexpected error occurred. Please try again.';
        document.getElementById('error-message').style.display = 'block';
    }
});
