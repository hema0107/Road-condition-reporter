document.addEventListener('DOMContentLoaded', function() {
    fetchUserReports();
});

function fetchUserReports() {
    fetch('http://localhost:5000/api/reports', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken')}` // Assuming you store the token in localStorage
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayReports(data.reports);
        } else {
            document.getElementById('reports').innerHTML = '<p>An error occurred while fetching reports.</p>';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('reports').innerHTML = '<p>An error occurred while fetching reports.</p>';
    });
}

function displayReports(reports) {
    const reportsContainer = document.getElementById('reports');
    reportsContainer.innerHTML = '';

    reports.forEach(report => {
        const reportElement = document.createElement('div');
        reportElement.className = 'report-item';

        reportElement.innerHTML = `
            <h3>${report.conditionType}</h3>
            <p><strong>Location:</strong> ${report.location}</p>
            <p><strong>Description:</strong> ${report.description}</p>
            ${report.photoUrl ? `<img src="${report.photoUrl}" alt="Report Photo">` : ''}
        `;

        reportsContainer.appendChild(reportElement);
    });
}
