// Initialize the Leaflet Map on the map page
if (document.getElementById('map')) {
    const map = L.map('map').setView([51.505, -0.09], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map);
    
    // Example marker
    L.marker([51.505, -0.09]).addTo(map)
        .bindPopup('Reported Condition: Pothole').openPopup();
}

// Login Form Submission
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        const response = await fetch('http://localhost:5000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        if (data.success) {
            window.location.href = 'dashboard.html';
        } else {
            alert('Login failed');
        }
    });
}

// Report Form Submission
const reportForm = document.getElementById('reportForm');
if (reportForm) {
    reportForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const conditionType = document.getElementById('conditionType').value;
        const location = document.getElementById('location').value;
        const description = document.getElementById('description').value;
        const photo = document.getElementById('photo').files[0];

        const formData = new FormData();
        formData.append('conditionType', conditionType);
        formData.append('location', location);
        formData.append('description', description);
        formData.append('photo', photo);

        const response = await fetch('http://localhost:5000/api/reports', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        if (data.success) {
            alert('Report submitted successfully');
        } else {
            alert('Failed to submit report');
        }
    });
}
