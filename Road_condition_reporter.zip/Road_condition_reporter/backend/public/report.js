document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/reports')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const reportsContainer = document.getElementById('reports-container');
                data.reports.forEach(report => {
                    const reportElement = document.createElement('div');
                    reportElement.classList.add('report');
                    reportElement.innerHTML = `
                        <h2>${report.conditionType}</h2>
                        <p><strong>Location:</strong> ${report.location}</p>
                        <p><strong>Description:</strong> ${report.description}</p>
                        <p><strong>Reported At:</strong> ${new Date(report.createdAt).toLocaleString()}</p>
                        ${report.photoUrl ? `<img src="${report.photoUrl}" alt="Report Photo" />` : ''}
                    `;
                    reportsContainer.appendChild(reportElement);
                });
            } else {
                console.error('Failed to fetch reports:', data.message);
            }
        })
        .catch(error => console.error('Error fetching reports:', error));
});
