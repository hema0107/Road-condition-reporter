// Initialize the map centered on Chennai 
const map = L.map('map').setView([13.0827, 80.2158], 12);

// Add OpenStreetMap tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

// Store markers to handle filtering
const markers = [];

// Function to add markers to the map
function addMarker(lat, lng, condition, placeName) {
    let color;
    switch (condition) {
        case 'pothole':
            color = 'red';
            break;
        case 'traffic':
            color = 'yellow';
            break;
        case 'accident':
            color = 'green';
            break;
        default:
            color = 'blue';
    }

    const marker = L.circleMarker([lat, lng], { color: color, radius: 10 }).addTo(map);
    marker.bindPopup(`${condition.charAt(0).toUpperCase() + condition.slice(1)} reported here at ${placeName}.`);
    markers.push({ marker, condition, lat, lng, placeName }); // Store placeName
}

// Handle form submission to add marker
document.getElementById('submit-report').addEventListener('click', function () {
    const placeValue = document.getElementById('place-select').value;
    const conditionValue = document.getElementById('condition-select').value;

    if (placeValue && conditionValue) {
        const [lat, lng] = placeValue.split(',').map(Number);
        
        // Validate latitude and longitude
        if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
            addMarker(lat, lng, conditionValue.toLowerCase(), placeValue); // Pass placeValue
            document.getElementById('thank-you-message').style.display = 'block';
            setTimeout(() => {
                document.getElementById('thank-you-message').style.display = 'none';
            }, 3000);
        } else {
            alert('Invalid latitude or longitude.');
        }
    } else {
        alert('Please select a place and condition type.');
    }
});

// Handle filtering of markers based on condition type
document.getElementById('apply-filter').addEventListener('click', function () {
    const filterValue = document.getElementById('filter-select').value.toLowerCase();
    const filteredLocations = document.getElementById('filtered-locations');
    
    // Clear previous filtered locations
    filteredLocations.innerHTML = '';

    markers.forEach(({ marker, condition, lat, lng, placeName }) => {
        if (filterValue === 'all' || filterValue === condition) {
            marker.addTo(map);
            // Display the location with place name
            const locationItem = document.createElement('div');
            locationItem.innerText = `Condition: ${condition.charAt(0).toUpperCase() + condition.slice(1)}, Location: ${placeName} (Lat: ${lat}, Lng: ${lng})`;
            filteredLocations.appendChild(locationItem);
        } else {
            map.removeLayer(marker);
        }
    });
});
