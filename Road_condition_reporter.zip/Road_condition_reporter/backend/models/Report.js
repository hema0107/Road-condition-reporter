const mongoose = require('mongoose');

const ReportSchema = new mongoose.Schema({
    conditionType: { type: String, required: true },
    location: { type: String, required: true },
    description: { type: String, required: true },
    photoUrl: String, // URL for uploaded photo
    createdAt: { type: Date, default: Date.now } // Automatically add a timestamp
});

module.exports = mongoose.model('Report', ReportSchema);
