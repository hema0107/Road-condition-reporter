const express = require('express');
const Report = require('../models/Report');
const router = express.Router();

router.post('/', async (req, res) => {
    try {
        const { conditionType, location, description } = req.body;
        const newReport = new Report({ conditionType, location, description });
        await newReport.save();
        res.status(200).json({ success: true, message: 'Report submitted successfully' });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
});

module.exports = router;